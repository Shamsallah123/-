document.getElementById("contactForm").addEventListener("submit", function(event) {
    event.preventDefault();
    alert("ستاسو پیغام په بریالیتوب سره واستول شو. مننه!");
    this.reset();
});
